<!-- SAHRUL VAN KHAN -->
<?php
$emailku = 'Adilseha46@gmail.com';
?>